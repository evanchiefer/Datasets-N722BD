# N722BD (Learjet 60), 1 Nov 2026: data behind the graphics

This folder holds every input and intermediate dataset used for the descent graphs, the Mach, limits and terminal-velocity figures, the raw-data tables, and the synced ATC overlay video.

**Three parts.** The data comes as three zips, each under 25 MB. Unzip all three into the same place and they merge into this one `N722BD_data` folder. Each part has a `PART_n_of_3.txt` that lists what it holds.

**Time base.** `rel_s` is seconds after **17:48:00Z**. `clip_s` is seconds into the uncut ZMA audio. They are related by `rel = clip − 22.97` (good to about ±1.5 s; see `2_derived/csv/sync_and_constants.json`).
**Units.** The CSVs put units in their column names. In the working files (json/npz), altitude is in metres and speed in m/s unless the name says otherwise.

## 1_raw: inputs as received

| file | what it is |
|---|---|
| `adsb/N722BD-track-EGM96.kml` | ADS-B GNSS height track (EGM96 geoid), metres |
| `adsb/N722BD-track-EGM96_avg.kml` | same track, averaged version |
| `adsb/N722BD-track-press_alt_uncorrected.kml` | ADS-B barometric (pressure) altitude track. It freezes at 8,750 ft after 17:49:23.6Z |
| `adsb/426342df.csv`, `426342df.kml` | flight-tracker export: position, altitude, ground speed (kt), track. Timestamps are truncated, so +0.52 s is applied |
| `adsb/manual_readings_*.{csv,txt}` | the 9-second tracker readings used for the first descent graph |
| `adsb/screen_recordings/` | the tracker screen recordings (110423 readouts, 110450 ADS-B Exchange altitude panel, 110451 ADS-B Exchange replay) and the last-signal screenshot |
| `weather/MFL_sounding_2026110112.{txt,jpg}` | Miami (MFL) 12Z sounding. The text `%RAW%` block holds pressure, height, temperature, dew point and wind; −9999 means missing |
| `weather/surface_obs/` | surface observations near 17:45Z: KPBI, KBCT (Boca), CWOP DW0275 Lake Worth, FAWN Wellington, FD38 |
| `aircraft/learjet60_limits_used.txt` | the VMO/MMO limit schedule used |
| `audio/110463_ZMA_uncut.mp4` | uncut Miami Center (ZMA) audio, used for the overlay |
| `audio/110472_ZMA_edited_captioned.mp4` | edited ZMA clip with burned-in captions, used for caption text and timing |

## 2_derived: what was computed

**`csv/` (readable copies)**

| file | contents |
|---|---|
| `overlay_timeseries.csv` | every value the overlay video draws, at 30 Hz from 17:47:10 to the last fix: altitude, vertical speed, ground speed, true airspeed, total speed, Mach, indicated airspeed and its limit, pressure altitude, path angle, % of terminal velocity |
| `mach_sounding_corrected.csv` | final sounding-corrected speeds and Mach for the dive, with 5–95% bootstrap bands |
| `learjet60_limits_comparison.csv` | Mach and indicated airspeed against the Learjet 60 limits, with 5–95% bands |
| `terminal_velocity_ratio.csv` | speed as a fraction of straight-down terminal velocity (constant-drag and drag-rise versions) |
| `sounding_profile_MFL_12Z.csv` | the parsed sounding, plus virtual temperature and speed of sound |
| `adsb_kml_points.csv` | all three KML tracks as one table (rel time, lat/lon, metres and feet) |
| `adsb_csv_with_rel_time.csv` | the tracker CSV with the corrected rel time |
| `captions_uncut_audio.csv` | corrected captions with clip time and UTC |
| `caption_ocr_edited_clip.csv` | raw OCR of the edited clip's captions (line and highlighted word every 0.2 s) |
| `sync_and_constants.json` | sync offset, the two altitude-call anchors, muted sections, CSV time correction, last fix and impact time |

**`working_files/`** holds the files exactly as the scripts read and wrote them: `kml.json`, `dive.npz`, `mach_direct.npz`, `mach_spline.json`, `atm.json` (lapse-rate fit from surface obs + the baro/GNSS pair), `final_sounding.json`, `limits.json`, `term.json`/`term_in.npz`/`term3.json` (terminal velocity), `bank.json` (bank/load estimate), `anim_data.npz` (overlay), `off4.json` (sync), plus `early_physics_model/`. That last folder holds the pre-ADS-B extrapolation runs behind the first Mach/drag figures; the ADS-B analysis superseded them.

**`audio/ZMA_uncut_with_mutes.flac`** is the overlay soundtrack (lossless).

## 3_graphics: what was made from it

| graphic | built from |
|---|---|
| `descent_graph.png` | manual tracker readings (first estimate, before ADS-B) |
| `descent_physics.png`, `mach1_families.png` | early extrapolation model with transonic drag (`early_physics_model/`), superseded |
| `n722bd_final.png` | ADS-B KML + CSV, MFL sounding → `final_sounding.json` |
| `n722bd_limits.png` | `limits.json` + Learjet 60 limits |
| `n722bd_terminal.png` | `term3.json` |
| `n722bd_raw_kml.png`, `n722bd_raw_csv.png` | last 10 s of the raw KML and CSV |
| `video/N722BD_synced_uncut_captioned_v3.mp4` | `anim_data.npz`, captions, uncut audio with mutes, sync offset −22.97 s |

The earlier overlay videos used a superseded sync and are not included. The code that renders the overlay is in the separate `n722bd_overlay.zip`.
