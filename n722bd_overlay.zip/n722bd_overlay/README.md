# N722BD synced data overlay

Renders the 1920×1080, 30 fps overlay of the N722BD (Learjet 60) ADS-B data in sync with the uncut ZMA (Miami Center) audio. It draws live readouts, altitude, speed and Mach charts with the Learjet 60 limits, captions, and a waveform with call markers.

## Requirements

- Python 3.9+ with `pip install -r requirements.txt` (numpy, scipy, matplotlib, pillow)
- [ffmpeg](https://ffmpeg.org/) on your PATH (decodes the audio and encodes the video)

## Run (from this folder)

```bash
python src/parse_kml.py        # 1. KML tracks           -> data/kml.json
python src/prep_data.py        # 2. derived series        -> data/anim_data.npz
python src/make_audio.py       # 3. audio + mutes         -> audio/edited44.wav, audio/edited16.wav
python src/render_overlay.py stills 87.2 105.9   # optional: check frames -> out/still_*.jpg
python src/render_overlay.py video               # 4. full video          -> out/N722BD_synced_uncut_captioned.mp4
```

`data/kml.json` and `data/anim_data.npz` are already included, so you can skip steps 1–2. Step 3 is required: the audio is rebuilt from `inputs/110463.mp4`. A full render takes 2–3 minutes.

## Layout

| path | what it is |
|---|---|
| `inputs/` | raw files: the three ADS-B KML tracks, the ADS-B CSV (ground speed/track), the MFL 12Z sounding, the uncut audio |
| `src/config.py` | file paths, **sync offset `OFF`**, **audio `MUTES`**, video size/fps |
| `src/captions.py` | caption list `(start, end, text)` in clip seconds, so you can edit it directly |
| `src/parse_kml.py` | KML → JSON |
| `src/prep_data.py` | spline-smoothed GNSS altitude → vertical speed; sounding winds/temperature → true airspeed, Mach, indicated airspeed, pressure altitude, limit bands |
| `src/make_audio.py` | extracts the audio and silences the omitted sections with 20 ms fades |
| `src/render_overlay.py` | the graphic: static matplotlib background + per-frame PIL layers piped to ffmpeg |
| `data/terminal_ratio.json` | precomputed "% of straight-down terminal velocity" curve (median of an 800-draw bootstrap with transonic drag rise); `prep_data.py` reads it |

## Time conventions

- **rel**: seconds after 17:48:00Z, 1 Nov 2026. All data uses this.
- **clip**: seconds into the uncut audio. Captions, mutes and call markers use this.
- **rel = clip + OFF**, with `OFF = -22.97`. This was fitted so "twenty-two thousand feet" and "we're out of ten" line up with the barometric altitude passing 22,000 ft and 10,000 ft, allowing a 0.5 s speaking delay. The two calls agree within about 2 s, so the alignment is good to about ±1.5 s.

## Common edits

- **Shift the sync:** change `OFF` in `config.py`. A more negative value moves the audio later relative to the data.
- **Fix a caption:** edit its line in `captions.py`. Text in `[brackets]` is drawn grey.
- **Mute or unmute audio:** edit `MUTES` in `config.py`, then rerun `make_audio.py`.
- **Waveform markers:** edit `CALLS` in `render_overlay.py`. Each entry is clip second, label, `'l'`/`'r'` text side, and row 0/1.
- **Chart event lines:** edit `EVENTS` and `EVENT_POS` in `render_overlay.py`.
- Always check a few stills before a full render.
