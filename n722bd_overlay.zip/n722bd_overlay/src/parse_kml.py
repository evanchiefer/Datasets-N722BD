"""Step 1 - parse the ADS-B KML tracks into data/kml.json.

Each track becomes {t: [unix seconds], lon, lat, alt: [metres]}.
Run:  python src/parse_kml.py
"""
import re, json, datetime as dt
import numpy as np
from config import KML_FILES, KML_JSON

out = {}
for key, path in KML_FILES.items():
    s = open(path).read()
    whens = re.findall(r'<when\s*>([^<]+)</when>', s)
    coords = re.findall(r'<gx:coord\s*>([^<]+)</gx:coord>', s)
    assert len(whens) == len(coords), (key, len(whens), len(coords))
    t = [dt.datetime.fromisoformat(w.strip().replace('Z', '+00:00')).timestamp() for w in whens]
    c = np.array([[float(x) for x in cc.split()] for cc in coords])
    out[key] = dict(t=t, lon=c[:, 0].tolist(), lat=c[:, 1].tolist(), alt=c[:, 2].tolist())
    print('%-8s %4d points' % (key, len(t)))
json.dump(out, open(KML_JSON, 'w'))
print('wrote', KML_JSON)
