"""Step 2 - derive every series the overlay shows and save data/anim_data.npz.

Inputs: data/kml.json (GNSS + baro altitude), the ADS-B CSV (ground speed, track),
the MFL 12Z sounding (temperature, dew point, wind by height), and the precomputed
terminal-velocity ratio (data/terminal_ratio.json).

Method
  * GNSS altitude -> smoothing spline (k=4, s = N*20 m^2); its derivative is vertical speed.
  * Ground speed and unwrapped track from the CSV (CSV stamps are truncated -> +0.52 s).
  * Air-relative speed: subtract sounding wind (blended to the PBI surface wind below 300 m).
  * Mach = TAS / speed of sound from the sounding virtual temperature.
  * Indicated airspeed = calibrated airspeed from Mach and sounding static pressure.
  * Pressure altitude from the same pressure picks the Learjet 60 limit band:
      VMO 300 KIAS < 8,000 ft; 340 KIAS 8,000-20,000; 340->330 20,000-23,000; 330 to 26,750 ft
      MMO 0.81 from 26,750 to 37,000 ft, tapering to 0.78 at 43,000 ft.
Run:  python src/prep_data.py
"""
import json, csv, datetime as dt
import numpy as np
from scipy.interpolate import UnivariateSpline
from config import KML_JSON, CSV_FILE, SOUNDING_FILE, TERMINAL_JSON, ANIM_DATA

FT = 0.3048
T0 = dt.datetime(2026, 11, 1, 17, 48, 0, tzinfo=dt.timezone.utc).timestamp()
LASTFIX = 92.78                                   # last ADS-B fix, rel seconds
te = np.arange(-50.0, LASTFIX + 1e-9, 1 / 30)     # one sample per video frame

# ---------- ADS-B altitude tracks ----------
kml = json.load(open(KML_JSON))
def series(key):
    t = np.array(kml[key]['t']); i = np.argsort(t, kind='stable')
    t = t[i] - T0; a = np.array(kml[key]['alt'])[i]
    _, u = np.unique(t, return_index=True)
    return t[u], a[u]
tg, zg = series('geo'); m = tg >= -60; tg, zg = tg[m], zg[m]

# ---------- ADS-B ground speed / track ----------
rows = list(csv.DictReader(open(CSV_FILE)))
tc = np.array([int(r['Timestamp']) - T0 for r in rows]) + 0.52
gs = np.array([float(r['Speed']) for r in rows]) * 0.514444
trk = np.degrees(np.unwrap(np.radians([float(r['Direction']) for r in rows])))
mc = tc > -90; tc, gs, trk = tc[mc], gs[mc], trk[mc]

# ---------- sounding ----------
L = open(SOUNDING_FILE).read().split('%RAW%')[1].split('%END%')[0].strip().splitlines()
A = np.array([[float(x) for x in l.split(',')] for l in L])
p, h, T, Td, wd, ws = A.T                          # hPa, m, C, C, deg, kt
ok = h < 14000; p, h, T, Td, wd, ws = p[ok], h[ok], T[ok], Td[ok], wd[ok], ws[ok]
es = 6.112 * np.exp(17.67 * Td / (Td + 243.5)); q = 0.622 * es / (p - 0.378 * es)
Tv = (T + 273.15) * (1 + 0.608 * q)                # virtual temperature, K
w = ws >= 0; hw = h[w]
uw = -ws[w] * 0.514444 * np.sin(np.radians(wd[w]))   # wind blowing TOWARD east
vw = -ws[w] * 0.514444 * np.cos(np.radians(wd[w]))   # wind blowing TOWARD north
def wind(z):
    a = np.interp(z, hw, uw); b = np.interp(z, hw, vw)
    f = np.clip((300 - z) / 300, 0, 1)               # blend to ~10 m/s easterly near the surface
    return (1 - f) * a + f * (-10.0), (1 - f) * b

# ---------- airspeed helpers ----------
a0, p0 = 340.294, 101325.0
def cas_from(M, pz):
    """calibrated airspeed (kt) from Mach and static pressure (Pa), subsonic"""
    qc = pz * ((1 + 0.2 * M ** 2) ** 3.5 - 1)
    return a0 * np.sqrt(5 * ((qc / p0 + 1) ** (2 / 7) - 1)) / 0.514444
def vmo(ft): return np.where(ft < 8000, 300., np.where(ft < 20000, 340., np.where(ft < 23000, 340 - (ft - 20000) / 3000 * 10, 330.)))
def mmo(ft): return np.where(ft <= 37000, 0.81, np.where(ft < 43000, 0.81 - (ft - 37000) / 6000 * 0.03, 0.78))

# ---------- the derivation ----------
sp = UnivariateSpline(tg, zg, k=4, s=len(tg) * 20.0 ** 2)
z = sp(te); vz = -sp.derivative()(te)               # vz > 0 means descending (m/s)
g_ = np.interp(te, tc, gs); trk_i = np.interp(te, tc, trk)
ge = g_ * np.sin(np.radians(trk_i)); gn = g_ * np.cos(np.radians(trk_i)); we, wn = wind(z)
TAS = np.hypot(vz, np.hypot(ge - we, gn - wn))
Mm = TAS / np.sqrt(1.4 * 287.05 * np.interp(z, h, Tv))
pz = np.interp(z, h, p) * 100
CAS = cas_from(Mm, pz)
PA = (288.15 / 0.0065) * (1 - (pz / p0) ** (1 / 5.25588)) / FT   # pressure altitude, ft
Vg = np.hypot(vz, g_)                                             # ground-relative total speed
gam = np.degrees(np.arctan2(vz, g_))                              # flight-path angle, + = down
lim_cas = np.where(PA < 26750, vmo(PA), cas_from(mmo(PA), pz))

# terminal-velocity ratio (fraction of straight-down terminal speed), defined late in the dive
T3 = json.load(open(TERMINAL_JSON))
R = np.interp(te, T3['te'], T3['R'], left=np.nan); R[te < 49.6] = np.nan

# raw ADS-B points for the scatter / raw-report box
rtg, rzg = series('geo'); rtb, rzb = series('baro')
s = rtg > -60; rtg, rzg = rtg[s], rzg[s]; s = rtb > -60; rtb, rzb = rtb[s], rzb[s]

# events
imax = np.argmax(np.where(rtg > 0, rzg, -1)); dstart = rtg[imax + np.argmax(rzg[imax:] < rzg[imax] - 60)]
mmo_t = te[np.argmax((Mm > 0.81) & (te > 0))]
pk = np.argmax(np.where(te > 40, Mm, 0))
print('descent clearly under way by rel %.1f s | passes Mach 0.81 at rel %.1f s | peak Mach %.3f at rel %.1f s'
      % (dstart, mmo_t, Mm[pk], te[pk]))

np.savez(ANIM_DATA, te=te, vz=vz, z=z, gs=g_, TAS=TAS, Vg=Vg, M=Mm, CAS=CAS, PA=PA, gam=gam, lim_cas=lim_cas, R=R,
         rtg=rtg, rzg=rzg, rtb=rtb, rzb=rzb, rtc=tc, rgs=gs, rtrk=np.mod(trk, 360),
         dstart=dstart, mmo_t=mmo_t, pk_t=te[pk], pk_M=Mm[pk])
print('end of data: total %.0f m/s, Mach %.2f, IAS %.0f kt -> wrote %s' % (Vg[-1], Mm[-1], CAS[-1], ANIM_DATA))
