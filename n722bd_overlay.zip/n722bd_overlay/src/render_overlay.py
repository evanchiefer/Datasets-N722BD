"""Step 4 - render the synced data overlay (1920x1080, 30 fps) and mux the ATC audio.

Layout
  left   status line, eight live readouts, latest raw ADS-B report
  right  altitude / speed components / Mach charts drawn up to the current instant
  bottom caption bar, then the audio waveform with call markers and a playhead
A static background (axes, grid, limit lines, waveform) is drawn once with matplotlib;
each frame is that image plus the live layers drawn with PIL, piped as raw RGB to ffmpeg.

Run
  python src/render_overlay.py stills 87.2 105.9   # check frames at these clip seconds -> out/
  python src/render_overlay.py video               # full render + audio mux -> out/
"""
import sys, os, wave, json, subprocess
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageFont
from config import (ANIM_DATA, TERMINAL_JSON, AUDIO_16K, AUDIO_44K, OUT_DIR, VIDEO_SILENT, VIDEO_FINAL,
                    OFF, MUTES, W, H, FPS)
from captions import CAPS

FT = 0.3048
LASTFIX = 92.78      # last ADS-B fix (rel s) = 17:49:32.8Z, 417 ft
IMPACT = 93.2        # estimated impact (rel s) = 17:49:33.2Z

# ---------------- data ----------------
D = dict(np.load(ANIM_DATA)); te = D['te']
# carry the terminal-velocity ratio from its last smoothed value to the endpoint estimate
_end = json.load(open(TERMINAL_JSON))['end_md']; _k = te > 90.5
D['R'] = D['R'].copy(); D['R'][_k] = np.interp(te[_k], [90.5, 92.78], [D['R'][np.argmin(abs(te - 90.5))], _end])

# ---------------- audio ----------------
w = wave.open(AUDIO_16K); sr = w.getframerate()
x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float) / 32768
DUR = len(x) / sr; NF = int(DUR * FPS)
_h = sr // 10
_db = np.array([20 * np.log10(np.sqrt(np.mean(x[i * _h:(i + 1) * _h] ** 2)) + 1e-9) for i in range(len(x) // _h)])
_act = _db > -28
def speech_at(tc):
    """True where there is clear speech but no caption (shows a '[speech]' placeholder)."""
    i = int(tc * 10); lo, hi = max(0, i - 4), min(len(_act), i + 5)
    if any(a - 0.3 <= tc < b + 0.3 for a, b in MUTES): return False
    if any(a - 0.4 <= tc < b + 0.9 for a, b, _ in CAPS): return False
    return bool(_act[lo:hi].mean() > 0.6)

# ---------------- palette / time labels ----------------
BG = '#161615'; PANEL = '#1f1f1d'; TX = '#f0efec'; TX2 = '#c3c2b7'; MUT = '#8a8984'; GRID = '#2f2f2c'
BLUE = '#3987e5'; ORNG = '#d95926'; AQUA = '#199e70'; YEL = '#c98500'; RED = '#e66767'
def utc(t):
    s = 48 * 60 + t; m = int(s // 60); return '17:%02d:%04.1fZ' % (m, s - 60 * m)
def utc0(t):
    s = 48 * 60 + t; m = int(s // 60); return '17:%02d:%02dZ' % (m, round(s - 60 * m))
T0, T1 = OFF, OFF + DUR          # chart x-range in rel seconds = the whole clip

# ---------------- static background (matplotlib) ----------------
plt.rcParams.update({'font.family': 'DejaVu Sans', 'text.color': TX, 'axes.labelcolor': TX2,
                     'xtick.color': TX2, 'ytick.color': TX2, 'axes.edgecolor': GRID})
fig = plt.figure(figsize=(W / 100, H / 100), dpi=100, facecolor=BG)
def axes_px(l, t, w_, h_): return fig.add_axes([l / W, 1 - (t + h_) / H, w_ / W, h_ / H])
CX, CW = 760, 1110
axA = axes_px(CX, 110, CW, 220); axS = axes_px(CX, 380, CW, 220); axM = axes_px(CX, 650, CW, 180)
CHART_SPANS = ((110, 330), (380, 600), (650, 830))
ticks = np.arange(-15, T1, 15)
for a, ttl in ((axA, 'Altitude'), (axS, 'Speed components'), (axM, 'Mach number')):
    a.set_facecolor(BG); a.grid(color=GRID, lw=0.8); a.set_axisbelow(True)
    for s in ('top', 'right'): a.spines[s].set_visible(False)
    a.set_xlim(T0, T1); a.set_xticks(ticks); a.set_xticklabels([utc0(t) for t in ticks] if a is axM else [], fontsize=10)
    a.tick_params(labelsize=10, length=0)
    a.text(0, 1.03, ttl, transform=a.transAxes, fontsize=15, fontweight='bold', color=TX, va='bottom')
    a.axvspan(7.0, 39.5, color='#ffffff', alpha=0.04, lw=0)      # gap in ground-speed reports
axA.set_ylim(0, 40000); axA.set_yticks([0, 10000, 20000, 30000, 40000]); axA.set_yticklabels(['0', '10k', '20k', '30k', '40k'])
axS.set_ylim(0, 420); axS.set_yticks([0, 100, 200, 300, 400])
axM.set_ylim(0.6, 1.06); axM.set_yticks([0.6, 0.7, 0.8, 0.9, 1.0])
axS.text(23.2, 410, 'no ground-speed reports\n(values interpolated)', fontsize=9, color=MUT, ha='center', va='top')
axM.axhline(0.81, color=RED, lw=1.4, ls=(0, (5, 3)))
axM.text(T1 - 1, 0.795, 'Learjet 60 max operating Mach 0.81', fontsize=9.5, color=RED, ha='right', va='top')
axM.axhline(1.0, color=MUT, lw=1, ls=(0, (2, 3))); axM.text(T1 - 1, 1.005, 'Mach 1', fontsize=9.5, color=MUT, ha='right', va='bottom')
def legend(a, items, y=1.03):
    xx = 0.22
    for lab, c in items:
        a.text(xx, y, '━ ' + lab, transform=a.transAxes, fontsize=11, color=c, va='bottom'); xx += 0.03 + 0.0105 * len(lab)
legend(axA, [('GNSS altitude', BLUE), ('barometric altitude', YEL), ('· raw ADS-B points', TX2)])
legend(axS, [('total', BLUE), ('vertical', ORNG), ('horizontal (ground speed)', AQUA)])
legend(axM, [('Mach (speed through air ÷ local speed of sound)', BLUE)])
# waveform strip
axW = axes_px(40, 975, W - 80, 80); axW.set_facecolor(BG); axW.axis('off')
bins = 1600; seg = len(x) // bins; env = np.array([np.abs(x[i * seg:(i + 1) * seg]).max() for i in range(bins)])
axW.fill_between(np.arange(bins) * seg / sr, -env, env, color='#4a4a46', lw=0); axW.set_xlim(0, DUR); axW.set_ylim(-1.05, 1.05)
fig.text(40 / W, 1 - 962 / H, 'ATC audio (clip time)', fontsize=11, color=TX2, va='bottom')
for s_ in range(0, int(DUR) + 1, 10):
    fig.text((40 + s_ / DUR * (W - 80)) / W, 1 - 1068 / H, '%d:%02d' % (s_ // 60, s_ % 60), fontsize=9, color=MUT, ha='center', va='top')
fig.canvas.draw()
bg = Image.frombuffer('RGBA', fig.canvas.get_width_height(), fig.canvas.buffer_rgba()).convert('RGB')
def mapper(a):
    tr = a.transData
    def f(xs, ys):
        p = tr.transform(np.column_stack([xs, ys])); return np.column_stack([p[:, 0], H - p[:, 1]])
    return f
mA, mS, mM = mapper(axA), mapper(axS), mapper(axM)
bbW = axW.get_window_extent(); wx0, wx1 = bbW.x0, bbW.x1; wy0, wy1 = H - bbW.y1, H - bbW.y0
yAt, yAb = H - axA.get_window_extent().y1, H - axA.get_window_extent().y0
yMt, yMb = H - axM.get_window_extent().y1, H - axM.get_window_extent().y0
plt.close(fig)

# ---------------- precomputed pixel paths ----------------
PA_ = mA(te, D['z'] / FT); PS_t = mS(te, D['Vg']); PS_v = mS(te, D['vz']); PS_h = mS(te, D['gs']); PM_ = mM(te, D['M'])
kgv = D['rtg'] >= OFF; kbv = D['rtb'] >= OFF
RTG = D['rtg'][kgv]; RAWG = mA(RTG, D['rzg'][kgv] / FT); RTB = D['rtb'][kbv]; RAWB = mA(RTB, D['rzb'][kbv] / FT)
y081 = mM(np.array([0.0]), np.array([0.81]))[0, 1]

# ---------------- fonts (DejaVu ships with matplotlib, so this works on any OS) ----------------
FD = os.path.join(matplotlib.get_data_path(), 'fonts', 'ttf') + os.sep
F = lambda n, s: ImageFont.truetype(FD + n, s)
fCap = F('DejaVuSans-Bold.ttf', 27); fCap2 = F('DejaVuSans-Bold.ttf', 22); fT = F('DejaVuSans-Bold.ttf', 26)
fS = F('DejaVuSans.ttf', 16); fL = F('DejaVuSans.ttf', 17); fV = F('DejaVuSansMono-Bold.ttf', 34); fVs = F('DejaVuSansMono.ttf', 18)
fClock = F('DejaVuSansMono-Bold.ttf', 54); fSm = F('DejaVuSans.ttf', 14); fEv = F('DejaVuSans.ttf', 13)
fStat = F('DejaVuSans-Bold.ttf', 20); fNote = F('DejaVuSans.ttf', 12); fMute = F('DejaVuSans.ttf', 11)

# ---------------- annotations ----------------
# chart events: (rel s, 'A' altitude chart or 'M' Mach chart, label)
EVENTS = [(1.0, 'A', 'altitude rises ~450 ft'), (19.0, 'A', 'descent begins'),
          (float(D['mmo_t']), 'M', 'passes Mach 0.81 limit'), (float(D['pk_t']), 'M', 'peak ≈ Mach %.2f' % float(D['pk_M'])),
          (83.6, 'A', 'baro altitude freezes (8,750 ft)'), (LASTFIX, 'A', 'last ADS-B fix, 417 ft')]
EVENT_POS = {'altitude rises ~450 ft': (yAt + 150, 'la'), 'descent begins': (yAt + 172, 'la'),
             'baro altitude freezes (8,750 ft)': (yAt + 30, 'ra'), 'last ADS-B fix, 417 ft': (yAt + 52, 'ra'),
             'passes Mach 0.81 limit': (yMb - 26, 'la')}
# waveform call markers: (clip s, label, 'l' text right of line / 'r' text left of line, row 0 top / 1 lower)
CALLS = [(26.23, 'crew asks for FL370', 'r', 1), (32.63, 'ATC: climb and maintain FL370', 'r', 0), (36.83, 'readback', 'l', 1),
         (54.25, 'Mayday', 'l', 0), (63.45, 'overspeed call', 'l', 1), (65.05, '“20,000 ft/min”', 'l', 0),
         (80.56, 'scream', 'r', 0), (85.75, '“descending 22,000 ft”', 'l', 0), (89.15, '“banking 60”', 'l', 1),
         (100.6, 'scream', 'l', 0), (101.43, '“look outside, Jack”', 'l', 1), (105.51, '“out of ten”', 'l', 0)]
REQUEST_T, CLEARED_T = 26.23 + OFF, 32.23 + OFF       # crew request / ATC clearance, rel s
SUBTITLE = ('ADS-B data and derived values, synced to uncut ZMA (Miami Center) audio · '
            'alignment ±1.5 s · auto-captions, corrected')
SYNC_NOTE = 'sync: “22,000 feet” call ↔ baro 22,300 ft · “out of ten” ↔ baro just under 10,000 ft (±1.5 s)'

def idx(t): return int(np.clip(np.searchsorted(te, t, side='right') - 1, 0, len(te) - 1))
I0 = int(np.searchsorted(te, OFF))          # first sample inside the chart window
def poly(dr, P, i, col, w=3):
    if i > I0: dr.line([tuple(p) for p in P[I0:i + 1]], fill=col, width=w, joint='curve')

def frame(tc):
    """Draw the frame for clip time tc (seconds)."""
    t = tc + OFF; im = bg.copy(); dr = ImageDraw.Draw(im)
    i = idx(min(t, LASTFIX))
    # ---- charts
    if t >= te[0]:
        over = np.where((D['M'][:i + 1] > 0.81) & (te[:i + 1] > 0))[0]          # shade Mach above the limit
        if len(over) > 1:
            pts = [tuple(p) for p in PM_[over[0]:over[-1] + 1]] + [(PM_[over[-1], 0], y081), (PM_[over[0], 0], y081)]
            dr.polygon(pts, fill='#4a2a2a')
        poly(dr, PA_, i, BLUE, 3)
        jb = np.searchsorted(RTB, t, side='right')
        if jb > 1: dr.line([tuple(p) for p in RAWB[:jb]], fill=YEL, width=2)
        jg = np.searchsorted(RTG, t, side='right')
        for p in RAWG[max(0, jg - 400):jg]: dr.ellipse([p[0] - 2, p[1] - 2, p[0] + 2, p[1] + 2], fill=TX2)
        poly(dr, PS_h, i, AQUA, 3); poly(dr, PS_v, i, ORNG, 3); poly(dr, PS_t, i, BLUE, 3); poly(dr, PM_, i, BLUE, 3)
        for P, c in ((PA_, BLUE), (PS_t, BLUE), (PS_v, ORNG), (PS_h, AQUA), (PM_, BLUE)):
            p = P[i]; dr.ellipse([p[0] - 5, p[1] - 5, p[0] + 5, p[1] + 5], fill=c, outline=BG, width=2)
    for te_, ax_, lab in EVENTS:
        if t >= te_:
            xx = (mA if ax_ == 'A' else mM)(np.array([te_]), np.array([0]))[0, 0]
            top, bot = (yAt, yAb) if ax_ == 'A' else (yMt, yMb)
            dr.line([(xx, top), (xx, bot)], fill='#5a5a55', width=1)
            y_, anc = EVENT_POS.get(lab, (yMt + 14, 'la'))
            dr.text((xx + 4 if anc == 'la' else xx - 4, y_), lab, font=fEv, fill=TX2, anchor=anc)
    cx = mA(np.array([min(max(t, T0), T1)]), np.array([0]))[0, 0]
    for top, bot in CHART_SPANS: dr.line([(cx, top - 5), (cx, bot)], fill=TX, width=1)
    if t >= IMPACT:
        xi = mA(np.array([IMPACT]), np.array([0]))[0, 0]
        for top, bot in CHART_SPANS: dr.line([(xi, top), (xi, bot)], fill=RED, width=2)
        dr.text((xi - 5, 612), 'impact ≈17:49:33.2Z', font=fEv, fill=RED, anchor='ra')
    # ---- waveform: mutes, call markers, playhead
    px = wx0 + tc / DUR * (wx1 - wx0)
    for a_, b_ in MUTES:
        xa = wx0 + a_ / DUR * (wx1 - wx0); xb = wx0 + b_ / DUR * (wx1 - wx0)
        dr.rectangle([xa, wy0 + 30, xb, wy1 - 30], fill='#2a2a28'); dr.text(((xa + xb) / 2, (wy0 + wy1) / 2), 'muted', font=fMute, fill=MUT, anchor='mm')
    for cs, lab, side, row in CALLS:
        xx = wx0 + cs / DUR * (wx1 - wx0); col = YEL if tc >= cs else MUT
        yl = wy0 - 36 + row * 17
        dr.line([(xx, yl + 14), (xx, wy1)], fill=col, width=2)
    for cs, lab, side, row in CALLS:          # labels on a background chip so upper-row lines pass behind them
        xx = wx0 + cs / DUR * (wx1 - wx0); col = YEL if tc >= cs else MUT
        yl = wy0 - 36 + row * 17; anc = 'ra' if side == 'r' else 'la'; px_ = xx - 5 if side == 'r' else xx + 5
        bb = dr.textbbox((px_, yl), lab, font=fSm, anchor=anc)
        dr.rectangle([bb[0] - 2, bb[1] - 1, bb[2] + 2, bb[3] + 1], fill=BG)
        dr.text((px_, yl), lab, font=fSm, fill=col, anchor=anc)
    # ---- caption bar
    cap = [c for c in CAPS if c[0] <= tc < c[1] + 0.35]
    bx0, bx1, by0, by1 = CX, CX + CW, 868, 930
    if cap:
        txt = cap[-1][2]; col = TX if not txt.startswith('[') else TX2
        fc = fCap; lines = []; cur = ''
        for wd in txt.split():
            tst = (cur + ' ' + wd).strip()
            if dr.textlength(tst, font=fc) > CW - 40 and cur: lines.append(cur); cur = wd
            else: cur = tst
        lines.append(cur)
        if len(lines) > 1: fc = fCap2
        dr.rounded_rectangle([bx0, by0, bx1, by1], radius=8, fill='#0c0c0b')
        for k, ln in enumerate(lines[:2]):
            yy = (by0 + by1) / 2 if len(lines) == 1 else by0 + 16 + k * 29
            dr.text(((bx0 + bx1) / 2, yy), ln, font=fc, fill=col, anchor='mm')
    elif speech_at(tc):
        dr.rounded_rectangle([bx0, by0, bx1, by1], radius=8, fill='#0c0c0b')
        dr.text(((bx0 + bx1) / 2, (by0 + by1) / 2), '[speech — no caption available]', font=fCap2, fill=MUT, anchor='mm')
    dr.line([(px, wy0 - 6), (px, wy1 + 4)], fill=TX, width=3)
    # ---- header + clock
    dr.text((40, 22), 'N722BD  ·  Learjet 60  ·  final minutes, Nov 1 2026', font=fT, fill=TX)
    dr.text((40, 60), SUBTITLE, font=fS, fill=TX2)
    dr.text((W - 40, 14), utc(t), font=fClock, fill=TX, anchor='ra')
    dr.text((W - 40, 76), 'clip %d:%04.1f' % (tc // 60, tc % 60), font=fS, fill=TX2, anchor='ra')
    # ---- status line
    if t >= IMPACT:                st, sc = 'IMPACT ≈17:49:33.2Z — no further data', RED
    elif t > LASTFIX:              st, sc = 'last ADS-B fix 17:49:32.8Z (417 ft)', RED
    elif t >= float(D['mmo_t']):   st, sc = 'DIVE — above max operating Mach 0.81', ORNG
    elif t >= 19.0:                st, sc = 'DESCENDING', YEL
    elif t >= CLEARED_T:           st, sc = 'CLEARED to FL370 by ATC', AQUA
    elif t >= REQUEST_T:           st, sc = 'CREW REQUESTS climb to FL370', AQUA
    elif t >= 1.0:                 st, sc = 'ALTITUDE RISING ~450 ft (turbulence reported)', AQUA
    else:                          st, sc = 'CRUISE, FL350', AQUA
    dr.rounded_rectangle([40, 108, 700, 148], radius=8, fill=PANEL); dr.text((56, 116), st, font=fStat, fill=sc)
    # ---- readouts
    j = idx(min(t, LASTFIX))
    alt = D['z'][j] / FT; vz = D['vz'][j]; gsv = D['gs'][j]; Vg = D['Vg'][j]; M = D['M'][j]
    cas = D['CAS'][j]; lim = D['lim_cas'][j]; gam = D['gam'][j]; R = D['R'][j]
    rows = [('GNSS altitude', '%s ft' % format(int(round(alt / 10) * 10), ','), TX),
            ('vertical speed', '{:+,d} ft/min'.format(int(round(-vz / FT * 60 / 100) * 100)), ORNG),
            ('ground speed', '%d kt' % round(gsv / 0.514444), AQUA),
            ('total speed', '%d m/s · %d mph' % (round(Vg), round(Vg * 2.23694)), BLUE),
            ('Mach', '%.2f' % M, RED if M > 0.81 else TX),
            ('indicated airspeed', '%d kt' % round(cas), RED if cas > lim else TX),
            ('flight-path angle', '%d° %s' % (round(abs(gam)), 'down' if gam >= 0 else 'up'), TX),
            ('of straight-down terminal velocity', '—' if np.isnan(R) else '%d%%' % round(100 * R), TX)]
    y = 165
    for lab, val, col in rows:
        dr.rounded_rectangle([40, y, 700, y + 76], radius=8, fill=PANEL)
        dr.text((56, y + 8), lab, font=fL, fill=TX2); dr.text((56, y + 31), val, font=fV, fill=col)
        if lab == 'indicated airspeed':
            dr.text((684, y + 12), 'limit %d kt' % round(lim), font=fVs, fill=TX2, anchor='ra')
            if cas > lim: dr.text((684, y + 40), '%.2f× the limit' % (cas / lim), font=fVs, fill=RED, anchor='ra')
        if lab == 'Mach': dr.text((684, y + 40), 'limit 0.81', font=fVs, fill=TX2, anchor='ra')
        if lab.startswith('of straight') and not np.isnan(R):
            b0, b1 = 380, 684; dr.rounded_rectangle([b0, y + 44, b1, y + 60], radius=6, fill='#2c2c2a')
            dr.rounded_rectangle([b0, y + 44, b0 + (b1 - b0) * min(R, 1.0), y + 60], radius=6, fill=BLUE)
        y += 82
    # ---- latest raw ADS-B report
    dr.rounded_rectangle([40, y + 4, 700, y + 120], radius=8, fill=PANEL)
    dr.text((56, y + 12), 'latest raw ADS-B report', font=fL, fill=TX2)
    tq = min(t, LASTFIX + 0.001)
    kg = np.searchsorted(D['rtg'], tq, side='right') - 1; kb = np.searchsorted(D['rtb'], tq, side='right') - 1
    kc = np.searchsorted(D['rtc'], t, side='right') - 1
    if kg >= 0:
        dr.text((56, y + 38), '%s  GNSS %s ft   baro %s ft' % (utc(D['rtg'][kg]), format(int(round(D['rzg'][kg] / FT)), ','),
                                                            format(int(round(D['rzb'][kb] / FT)), ',')), font=fVs, fill=TX)
    if kc >= 0:
        dr.text((56, y + 66), '%s  GS %d kt   track %d°' % (utc(D['rtc'][kc]), round(D['rgs'][kc] / 0.514444), round(D['rtrk'][kc])),
                font=fVs, fill=TX)
    dr.text((56, y + 95), SYNC_NOTE, font=fNote, fill=MUT)
    return im

if __name__ == '__main__':
    os.makedirs(OUT_DIR, exist_ok=True)
    mode = sys.argv[1] if len(sys.argv) > 1 else 'video'
    if mode == 'stills':
        for tc in map(float, sys.argv[2:]):
            path = os.path.join(OUT_DIR, 'still_%05.1f.jpg' % tc); frame(tc).save(path, quality=90); print('wrote', path)
    else:
        tmp = VIDEO_SILENT + '.part.mp4'
        p = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '%dx%d' % (W, H),
                              '-r', str(FPS), '-i', '-', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20',
                              '-pix_fmt', 'yuv420p', tmp], stdin=subprocess.PIPE)
        for n in range(NF):
            p.stdin.write(frame(n / FPS).tobytes())
            if n % 300 == 0: print('frame %d / %d' % (n, NF), flush=True)
        p.stdin.close()
        if p.wait() != 0: sys.exit('ffmpeg failed')
        os.replace(tmp, VIDEO_SILENT)
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', VIDEO_SILENT, '-i', AUDIO_44K, '-map', '0:v', '-map', '1:a',
                        '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', VIDEO_FINAL], check=True)
        print('wrote', VIDEO_FINAL)
