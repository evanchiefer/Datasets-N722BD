"""Step 3 - pull the uncut ZMA audio out of the mp4 and silence the omitted sections.

Writes audio/edited44.wav (44.1 kHz, muxed into the video) and audio/edited16.wav
(16 kHz, used for the waveform strip and the "[speech]" detector). Needs ffmpeg on PATH.
Run:  python src/make_audio.py
"""
import subprocess, wave, os
import numpy as np
from config import AUDIO_SOURCE, AUDIO_16K, AUDIO_44K, MUTES, FADE_S

def decode(path, sr):
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-vn', '-ac', '1', '-ar', str(sr), '-f', 's16le', '-'],
                         check=True, capture_output=True).stdout
    return np.frombuffer(raw, dtype=np.int16).astype(float)

def apply_mutes(x, sr):
    gain = np.ones(len(x)); nf = int(FADE_S * sr)
    ramp = 0.5 * (1 + np.cos(np.linspace(0, np.pi, nf)))          # 1 -> 0 raised cosine
    for a, b in MUTES:
        ia, ib = int(a * sr), int(b * sr)
        gain[ia:ib] = 0
        gain[max(0, ia - nf):ia] *= ramp[-(ia - max(0, ia - nf)):]   # fade out into the mute
        gain[ib:ib + nf] *= ramp[::-1][:len(gain[ib:ib + nf])]        # fade back in
    return x * gain

def save(path, x, sr):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    w = wave.open(path, 'wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
    w.writeframes(np.clip(np.round(x), -32768, 32767).astype(np.int16).tobytes()); w.close()

save(AUDIO_44K, apply_mutes(decode(AUDIO_SOURCE, 44100), 44100), 44100)
print('wrote', AUDIO_44K)
save(AUDIO_16K, decode(AUDIO_44K, 16000), 16000)      # 16 kHz copy resampled from the muted 44.1 kHz file
print('wrote', AUDIO_16K)
