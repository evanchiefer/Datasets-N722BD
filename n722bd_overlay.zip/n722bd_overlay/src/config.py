"""Shared settings for the N722BD overlay pipeline.

Every script runs from the project root (the folder that holds src/, inputs/, data/).
Times called "rel" are seconds after 17:48:00Z on 1 Nov 2026.
Times called "clip" are seconds into the uncut ZMA audio (inputs/110463.mp4).
"""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def P(*parts): return os.path.join(ROOT, *parts)

# ---------------- raw inputs ----------------
KML_FILES = {                                   # ADS-B tracks (altitude in metres)
    'geo':     P('inputs', 'N722BD-track-EGM96.kml'),                     # GNSS height, EGM96 geoid
    'geo_avg': P('inputs', 'N722BD-track-EGM96_avg.kml'),
    'baro':    P('inputs', 'N722BD-track-press_alt_uncorrected.kml'),     # barometric (pressure) altitude
}
CSV_FILE      = P('inputs', '426342df.csv')                 # ground speed (kt) + track (deg)
SOUNDING_FILE = P('inputs', 'MFL_sounding_2026110112.txt')  # Miami (MFL) 12Z sounding, %RAW% block
AUDIO_SOURCE  = P('inputs', '110463.mp4')                   # uncut ZMA (Miami Center) audio

# ---------------- intermediate / derived data ----------------
KML_JSON       = P('data', 'kml.json')               # written by parse_kml.py
TERMINAL_JSON  = P('data', 'terminal_ratio.json')    # terminal-velocity ratio (precomputed, see README)
ANIM_DATA      = P('data', 'anim_data.npz')          # written by prep_data.py, read by render_overlay.py
AUDIO_16K      = P('audio', 'edited16.wav')          # written by make_audio.py (waveform + speech detection)
AUDIO_44K      = P('audio', 'edited44.wav')          # written by make_audio.py (muxed into the video)

# ---------------- outputs ----------------
OUT_DIR       = P('out')
VIDEO_SILENT  = P('out', 'overlay_noaudio.mp4')
VIDEO_FINAL   = P('out', 'N722BD_synced_uncut_captioned.mp4')

# ---------------- sync ----------------
# rel = clip + OFF.  Fitted to two altitude callouts against the barometric altitude:
#   "twenty-two thousand feet" (clip 86.85 s)  <->  baro passes 22,000 ft at rel 64.42 s
#   "we're out of ten"         (clip 105.85 s) <->  baro passes 10,000 ft at rel 81.34 s
# with 0.5 s speaking delay -> offsets -21.93 and -24.01 s; mean used, about +/-1.5 s.
OFF = -22.97

# Audio sections silenced (clip seconds), with 20 ms raised-cosine fades.
MUTES = [(91.77, 96.33),     # "what is what"/"is your name" exchange
         (102.65, 103.69)]   # "we're gonna crash"
FADE_S = 0.020

# ---------------- render ----------------
W, H, FPS = 1920, 1080, 30
